package com.example.flutter_tutorial_3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
