//
//  DetailViewController.swift
//  tutorial8
//
//  Created by mobiledev on 21/5/2022.
//

import UIKit
import Firebase
import FirebaseFirestoreSwift

class DetailViewController: UIViewController {

    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var yearLabel: UILabel!
    @IBOutlet var durationLabel: UILabel!
    @IBOutlet var endLabel: UILabel!
    
    
    var movie : Movie?
    var movieIndex : Int? //used much later in tutorial
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        if let displayMovie = movie
        {
            self.navigationItem.title = displayMovie.title //this awesome line sets the page title
            titleLabel.text = "Game session: \(displayMovie.title)"
            yearLabel.text = "Score: \(String(displayMovie.year))"
            durationLabel.text = "Start Time: \(displayMovie.duration)"
            endLabel.text = "End Time: \(displayMovie.end)"
        }
    }
    @IBAction func onDelete(_ sender: Any) {
        (sender as! UIBarButtonItem).title = "Loading..."
        
        var flag = 0
        let alert = UIAlertController(title: "Are you sure you want to delete this session?", message: "There is no way to undo this", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler: { Action in
            print("Dismissed")
            flag = 0
        }))
        alert.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: { Action in
            print("Deleted")
            flag = 1
            if flag == 1 {
                flag = 0
                let db = Firestore.firestore()

                self.movie!.title = self.titleLabel.text!
                self.movie!.year = Int(self.yearLabel.text!)! //good code would check this is an int
                self.movie!.duration = self.durationLabel.text! //good code would check this is a float
                self.movie!.end = self.endLabel.text!
                do
                {
                    //update the database (code from lectures)
                    db.collection("movies").document(self.movie!.documentID!).delete(){ err in
                        if let err = err {
                            print("Error updating document: \(err)")
                        } else {
                            print("Document successfully updated")
                            //this code triggers the unwind segue manually
                            self.performSegue(withIdentifier: "deleteSegue", sender: sender)
                        }
                    }

                }
            }
        }))
        self.present(alert, animated: true)
        
    print("Cancel")
    }
}
/*
    func showActionsheet() -> String {
        var flag = 1
        let alert = UIAlertController(title: "Are you sure you want to delete this session?", message: "There is no way to undo this", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Dismiss", style: .cancel, handler: { Action in
            print("Dismissed")
            flag = 0
        }))
        alert.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: { Action in
            print("Deleted")
            flag = 1
        }))
        self.present(alertView, animated: true)
    }
*/
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */



