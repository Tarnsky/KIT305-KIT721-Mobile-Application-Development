//
//  Movie.swift
//  tutorial8
//
//  Created by mobiledev on 21/5/2022.
//


import Firebase
import FirebaseFirestoreSwift

public struct Movie : Codable
{
    @DocumentID var documentID:String?
    var title:String
    var year:Int
    var duration:String
    var end:String
}
