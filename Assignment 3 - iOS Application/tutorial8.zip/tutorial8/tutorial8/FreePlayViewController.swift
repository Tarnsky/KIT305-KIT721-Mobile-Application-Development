//
//  FreePlayViewController.swift
//  tutorial8
//
//  Created by mobiledev on 23/5/2022.
//
import Firebase
import FirebaseFirestoreSwift
import UIKit

class FreePlayViewController: UIViewController {

    @IBOutlet weak var startTimeLabel: UILabel!
    @IBOutlet weak var buttonOne: UIButton!
    @IBOutlet weak var buttonTwo: UIButton!
    @IBOutlet weak var buttonThree: UIButton!
    @IBOutlet weak var orderLabel: UILabel!
    @IBOutlet weak var pressedLabel: UILabel!
    @IBOutlet weak var scoreLabel: UILabel!
    
    var tracker = "1"
    var score = 0
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let startTime = getCurrentTime()
        let aRandInt = 1
        let bRandInt = 2
        let cRandInt = 3
        
        buttonOne.setTitle(String(aRandInt), for: .normal)
        buttonTwo.setTitle(String(bRandInt), for: .normal)
        buttonThree.setTitle(String(cRandInt), for: .normal)
        orderLabel.text = "Press the buttons in order"
        pressedLabel.text = "Press \(tracker) Next"
        scoreLabel.text = "Score: \(score)"
        startTimeLabel.isHidden = true
        startTimeLabel.text = startTime

    }
    func showAlert() {
        let alert = UIAlertController(title: "congratulations", message: "Game over. Press End Game to finish the session", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "ok", style: .cancel, handler: { Action in
            print("ok")
        }))
        present(alert, animated: true)
    }
    @IBAction func buttonOnePress(_ sender: Any) {
        print(buttonOne.currentTitle!)
        
        if (tracker == buttonOne.currentTitle){
            //Check tracker and add
            if (tracker == "1"){
                tracker = "2"
                pressedLabel.text = "Press \(tracker) Next"
                
            }
                else if (tracker == "2"){
                    tracker = "3"
                    pressedLabel.text = "Press \(tracker) Next"
                    
                }
                    else if (tracker == "3"){
                        tracker = "1"
                        score+=1
                        scoreLabel.text = "Score: \(score)"
                        pressedLabel.text = "Press \(tracker) Next"
                        if score == 5000 {
                            showAlert()
                            let db = Firestore.firestore()
                            print("\nINITIALIZED FIRESTORE APP \(db.app.name)\n")
                        let uuid = UUID().uuidString
                        let movieCollection = db.collection("movies")
                        
                            let matrix = Movie(title: uuid, year: score, duration: startTimeLabel.text!, end: getCurrentTime())
                        do {
                            try movieCollection.addDocument(from: matrix, completion: { (err) in
                                if let err = err {
                                    print("Error adding document: \(err)")
                                } else {
                                    print("Successfully created movie")
                                }
                            })
                        } catch let error {
                            print("Error writing city to Firestore: \(error)")
                        }
                            score = 0
                            buttonOne.isHidden = true
                            buttonTwo.isHidden = true
                            buttonThree.isHidden = true
                        }
                    }
        }
    }
    
    @IBAction func buttonTwoPress(_ sender: Any) {
            print(buttonTwo.currentTitle!)
            
            if (tracker == buttonTwo.currentTitle){
                //Check tracker and add
                if (tracker == "1"){
                    tracker = "2"
                    pressedLabel.text = "Press \(tracker) Next"
                    
                }
                    else if (tracker == "2"){
                        tracker = "3"
                        pressedLabel.text = "Press \(tracker) Next"
                        
                    }
                        else if (tracker == "3"){
                            tracker = "1"
                            score+=1
                            scoreLabel.text = "Score: \(score)"
                            pressedLabel.text = "Press \(tracker) Next"
                            if score == 5000 {
                                showAlert()
                                let db = Firestore.firestore()
                                print("\nINITIALIZED FIRESTORE APP \(db.app.name)\n")
                            let uuid = UUID().uuidString
                            let movieCollection = db.collection("movies")
                            
                                let matrix = Movie(title: uuid, year: score, duration: startTimeLabel.text!, end: getCurrentTime())
                            do {
                                try movieCollection.addDocument(from: matrix, completion: { (err) in
                                    if let err = err {
                                        print("Error adding document: \(err)")
                                    } else {
                                        print("Successfully created movie")
                                    }
                                })
                            } catch let error {
                                print("Error writing city to Firestore: \(error)")
                            }
                                score = 0
                                buttonOne.isHidden = true
                                buttonTwo.isHidden = true
                                buttonThree.isHidden = true
                            }

                            
                        }
            }
                
      
    }
    
    @IBAction func buttonThreePress(_ sender: Any) {
        print(buttonThree.currentTitle!)
        
        if (tracker == buttonThree.currentTitle){
            //Check tracker and add
            if (tracker == "1"){
                tracker = "2"
                pressedLabel.text = "Press \(tracker) Next"
                
            }
                else if (tracker == "2"){
                    tracker = "3"
                    pressedLabel.text = "Press \(tracker) Next"
                    
                }
                    else if (tracker == "3"){
                        tracker = "1"
                        score+=1
                        scoreLabel.text = "Score: \(score)"
                        pressedLabel.text = "Press \(tracker) Next"
                        if score == 5000 {
                            showAlert()
                            let db = Firestore.firestore()
                            print("\nINITIALIZED FIRESTORE APP \(db.app.name)\n")
                        let uuid = UUID().uuidString
                        let movieCollection = db.collection("movies")
                        
                            let matrix = Movie(title: uuid, year: score, duration: startTimeLabel.text!, end: getCurrentTime())
                        do {
                            try movieCollection.addDocument(from: matrix, completion: { (err) in
                                if let err = err {
                                    print("Error adding document: \(err)")
                                } else {
                                    print("Successfully created movie")
                                }
                            })
                        } catch let error {
                            print("Error writing city to Firestore: \(error)")
                        }
                            score = 0
                            buttonOne.isHidden = true
                            buttonTwo.isHidden = true
                            buttonThree.isHidden = true
                        }
                        
                    }
        }
            
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func getCurrentTime()-> String {
        let date = Date()
        let calendar = Calendar.current
        let hour = calendar.component(.hour, from: date)
        let minutes = calendar.component(.minute, from: date)
        let day = calendar.component(.day, from: date)
        let month = calendar.component(.month, from: date)
        let year = calendar.component(.year, from: date)
        var minuteTwo = "\(minutes)"
        if(minuteTwo.count == 1){
            minuteTwo = "0\(minutes)"
        }
        var hourTwo = "\(hour)"
        if(hourTwo.count == 1){
            hourTwo = "0\(hour)"
        }
        let theDate = "\(day)/\(month)/\(year) \(hourTwo):\(minuteTwo)"
        return theDate
    }}
