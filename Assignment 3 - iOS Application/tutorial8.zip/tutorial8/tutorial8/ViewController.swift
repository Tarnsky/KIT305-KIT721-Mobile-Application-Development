//
//  ViewController.swift
//  tutorial8
//
//  Created by mobiledev on 21/5/2022.
//

import UIKit
import Firebase
import FirebaseFirestoreSwift
class ViewController: UIViewController {

    @IBOutlet var NameLabel: UILabel!
    @IBAction func EditName(_ sender: Any) {
        NameLabel.text = "Hello Donkey"
    }
    override func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view.
        
            let db = Firestore.firestore()
            print("\nINITIALIZED FIRESTORE APP \(db.app.name)\n")
        let uuid = UUID().uuidString
        let movieCollection = db.collection("movies")
        print(getCurrentTime())
         let matrix = Movie(title: uuid, year: 5, duration: getCurrentTime(), end: getCurrentTime())
        do {
            try movieCollection.addDocument(from: matrix, completion: { (err) in
                if let err = err {
                    print("Error adding document: \(err)")
                } else {
                    print("Successfully created movie")
                }
            })
        } catch let error {
            print("Error writing city to Firestore: \(error)")
        }
         
        movieCollection.getDocuments() { (result, err) in
          //check for server error
          if let err = err
          {
              print("Error getting documents: \(err)")
          }
          else
          {
              //loop through the results
              for document in result!.documents
              {
                  //attempt to convert to Movie object
                  let conversionResult = Result
                  {
                      try document.data(as: Movie.self)
                  }

                  //check if conversionResult is success or failure (i.e. was an exception/error thrown?
                  switch conversionResult
                  {
                      //no problems (but could still be nil)
                      case .success(let movie):
                          print("Movie: \(movie)")
                          
                      case .failure(let error):
                          // A `Movie` value could not be initialized from the DocumentSnapshot.
                          print("Error decoding movie: \(error)")
                  }
              }
          }
        }
        
    }
    func getCurrentTime()-> String {
        let date = Date()
        let calendar = Calendar.current
        let hour = calendar.component(.hour, from: date)
        let minutes = calendar.component(.minute, from: date)
        let day = calendar.component(.day, from: date)
        let month = calendar.component(.month, from: date)
        let year = calendar.component(.year, from: date)
        var minuteTwo = "\(minutes)"
        if(minuteTwo.count == 1){
            minuteTwo = "0\(minutes)"
        }
        var hourTwo = "\(hour)"
        if(hourTwo.count == 1){
            hourTwo = "0\(hour)"
        }
        let theDate = "\(day)/\(month)/\(year) \(hourTwo):\(minutes)"
        return theDate
    }
}

