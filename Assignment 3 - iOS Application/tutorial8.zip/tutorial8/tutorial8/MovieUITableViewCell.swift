//
//  MovieUITableViewCell.swift
//  tutorial8
//
//  Created by mobiledev on 21/5/2022.
//

import UIKit

class MovieUITableViewCell: UITableViewCell {

    @IBOutlet var titleLabel: UILabel!
    @IBOutlet var subTitleLabel: UILabel!
    @IBOutlet var timeTitleLabel: UILabel!
    @IBOutlet var endTitleLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
